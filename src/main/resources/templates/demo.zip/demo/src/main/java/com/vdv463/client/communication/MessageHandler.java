package com.vdv463.client.communication;

public interface MessageHandler {
    void onMessage(Message message);
}
